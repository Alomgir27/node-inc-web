import React from "react";
import ReactDOM from "react-dom";
import App from "./App";
import AuthContextProvider from "./store/auth-context";

// import "./styles/styles.scss";
// email: shakeeb.aftab@node.inc
// password: Password}{2010

ReactDOM.render(
  <React.StrictMode>
    <AuthContextProvider>
      <App />
    </AuthContextProvider>
  </React.StrictMode>,
  document.getElementById("root")
);
