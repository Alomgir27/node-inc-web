import React, { useState } from "react";

import Modal from "./Modal";
import FancyInput from "../components/FancyInput";
import AddBtn from "../components/AddBtn";

import ModelServices from "./ModalServices";
import { BASEURL, sendNetworkRequest } from "../http/http-request";

const ModalAppointment = (props) => {
  const [servicesModalOpenState, setServicesModalOpenState] = useState(false);
  const [circles, setCircles] = useState([]);
  const [appointments, setAppointments] = useState([]);
  const [clientProfile, setClientProfile] = useState([]);
  const [note, setNote] = useState("");
  const [entity_id, setEntityId] = useState("");
  const [currency_id, setCurrencyId] = useState("");
  const [nodedwith, setNodedWith] = useState("");
  let emp = [];
  const [formState, setFormState] = useState({
    assign: "",
    note: "",
    sdate: "",
    edate: "",
    nodeclient: "",
    nodewith: "",
    due_date: "",
    name: "",
  });

  const inputChangeHandler = (e) => {
    const { name, value } = e.target;
    setFormState((prevVal) => {
      return { ...prevVal, [name]: value };
    });
  };

  const { employeeList, clientList, humanList } = props;
  emp = employeeList;
  const Services = [
    {
      id: 1,
      part: "Front Brake",
      partPrice: "100",
      imgSrc: "",
    },
    {
      id: 2,
      part: "Side Mirror",
      partPrice: "150",
    },
  ];

  const modalOpenHandler = (func) => {
    func(true);
  };

  const modalCloseHandler = (func) => {
    func(false);
  };
  const getClickCoords = (event) => {
    // from: https://stackoverflow.com/a/29296049/14198287
    var e = event.target;
    var dim = e.getBoundingClientRect();
    var x = event.clientX - dim.left;
    var y = event.clientY - dim.top;
    return [x, y];
  };
  const addCircle = (event) => {
    // get click coordinates
    let [x, y] = getClickCoords(event);
    console.log(x, y);

    // make new svg circle element
    // more info here: https://www.w3schools.com/graphics/svg_circle.asp
    let newCircle = (
      <div
        className="carcircle"
        style={{ top: `${y - 20}px`, left: `${x - 20}px` }}
      >
        {circles.length + 1}
      </div>
    );
    let newAppointment = (
      <div className="d-flex align-items-start car-appointment">
        <div className="item mb-3">
          {circles.length + 1}. Check for{" "}
          <strong>
            {" "}
            <select
              name="problems"
              id="problems"
              className="landmark-select p-0 border-0"
            >
              <option value="Knock Noise">Knock Noise</option>
              <option value="Rolling Noise">Rolling Noise</option>
              <option value="Silent Noise">Silent Noise</option>
              <option value="Liquid Flow">Liquid Flow</option>
              <option value="Malfunction">Malfunction</option>
              <option value="Don't ride straight">Don't ride straight</option>
              <option value="Air flow">Air flow</option>
              <option value="A/C check">A/C check</option>
              <option value="Check Engine Light">Check Engine Light</option>
              <option value="Brake Problem">Brake Problem</option>
              <option value="Hole/Puncture">Hole/Puncture</option>
              <option value="Battery">Battery</option>
            </select>{" "}
          </strong>{" "}
          located
          <strong>
            {" "}
            <select
              name="problems"
              id="problems"
              className="landmark-select p-0 border-0"
            >
              <option value="Front Right">Front Right</option>
              <option value="Back Right">Back Right</option>
              <option value="Right Side Center">Right Side Center</option>
              <option value="Front Left">Front Left</option>
              <option value="Back Left">Back Left</option>
              <option value="Left Side Center">Left Side Center</option>
              <option value="below">below</option>
            </select>{" "}
          </strong>{" "}
          on
          <strong>
            {" "}
            <select
              name="problems"
              id="problems"
              className="landmark-select p-0 border-0"
            ></select>{" "}
          </strong>
          Side, when{" "}
          <strong>
            <select
              name="problems"
              id="problems"
              className="landmark-select p-0 border-0"
            >
              <option value="High Speed">High Speed</option>
              <option value="Low Speed">Low Speed</option>
              <option value="Always">Always</option>
              <option value="Rolling over a hole">Rolling over a hole</option>
              <option value="Braking">Braking</option>
              <option value="Accleterating">Accleterating</option>
              <option value="Turn Left">Turn Left</option>
              <option value="Turn Right">Turn Right</option>
              <option value="Hot engine">Hot engine</option>
              <option value="Cold engine">Cold engine</option>
            </select>
          </strong>
        </div>
        <img
          id={appointments.length + 1}
          src="./assets/vectors/delete.svg"
          alt="delete"
          onClick={deleteAppointment}
          className="hover"
        />
      </div>
    );

    let allCircles = [...circles, newCircle];
    let allAppointment = [...appointments, newAppointment];

    // update 'circles'
    setCircles(allCircles);
    setAppointments(allAppointment);
  };
  const deleteAppointment = (e) => {
    console.log(e.target.id, "asdf");
    appointments.splice(e.target.id, 1);
    circles.splice(e.target.id, 1);
    setAppointments(appointments);
    setCircles(circles);
  };
  const fectchProfile = (id) => {
    setEntityId(id);
    humanList.map((e) => {
      if (e.entity_id.id == id) {
        setCurrencyId(e.home_currency_id.id);
      }
    });
    sendNetworkRequest(
      `${BASEURL}/profile/single-user/profile/all/${id}`,
      "GET",
      ""
    )
      .then((res) => {
        const profile = [
          {
            text: "Select in the menu",
            disabled: false,
            selected: true,
          },
        ];
        res.data.map((el) => {
          const data = JSON.parse(el.object_id.data);
          profile.push({
            text: data.name,
            value: data.serial,
            disabled: false,
            selected: true,
          });
          console.log(data);
        });
        setClientProfile(profile);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const createAppointment = async function createAppointment(event) {
    event.preventDefault();
    try {
      const noteResponse = await sendNetworkRequest(
        `${BASEURL}/core/notes`,
        "POST",
        {
          data: {
            note,
          },
        }
      );
      if (noteResponse && noteResponse.data) {
        sendNetworkRequest(`${BASEURL}/invoice`, "POST", {
          target_entity_id: entity_id,
          currency_id: currency_id,
          subtotal: 0,
          due_date: new Date(formState.edate),
          metadata: {
            name: formState.name,
            assign: formState.assign,
            sdate: formState.sdate,
            edate: formState.edate,
            nodedwith,
          },
          private_note_id: noteResponse.data.id,
          customer_note_id: noteResponse.data.id,
        })
          .then((res) => {
            if (res && res.data) {
              alert("Appointment has been successfully created");
            }
          })
          .catch((err) => {
            alert("An error occured when creating an appointment");
          });
      }
    } catch (error) {}
  };
  return (
    <form action="" onSubmit={createAppointment}>
      <div>
        <Modal className="modal-appointment" buttonText="Add" {...props}>
          <div className="client-modal-body">
            <div className="container-fluid px-0">
              <div className="row gy-5">
                <div className="col-lg-5">
                  <div className="row">
                    <h3 className="section-title mb-4">Appointment</h3>
                    <div className="col-9 mb-3">
                      <p className="mt-2">Name</p>
                      <FancyInput
                        sMargin
                        id="name"
                        name="name"
                        onChange={inputChangeHandler}
                        placeholder="Give a Title to your Appointment..."
                      />
                    </div>
                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">Assign to</p>
                      <FancyInput
                        select
                        options={
                          typeof employeeList != "undefined" ? employeeList : []
                        }
                        id="assignedTo"
                        name="assign"
                        onChange={inputChangeHandler}
                        placeholder="Select in the menu"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>

                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">Start time</p>
                      <FancyInput
                        sMargin
                        id="date"
                        type="datetime-local"
                        name="sdate"
                        onChange={inputChangeHandler}
                        placeholder="DD/MM/AA   at 00:000"
                        inputClassName="dateInput"
                      />
                    </div>
                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">End time</p>
                      <FancyInput
                        sMargin
                        id="date"
                        type="datetime-local"
                        name="edate"
                        onChange={inputChangeHandler}
                        placeholder="start time"
                        inputClassName="dateInput"
                      />
                    </div>
                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">Node Client</p>
                      <FancyInput
                        select
                        options={
                          typeof clientList != "undefined" ? clientList : []
                        }
                        id="assignedTo"
                        value={
                          typeof clientList != "undefined" ? clientList : []
                        }
                        name="nodeclient"
                        onChange={(e) => {
                          fectchProfile(e.target.value);
                        }}
                        placeholder="Select in the menu"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>
                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">Noded with</p>
                      <FancyInput
                        select
                        options={
                          typeof clientProfile != "undefined"
                            ? clientProfile
                            : []
                        }
                        value={
                          typeof clientProfile != "undefined"
                            ? clientProfile
                            : []
                        }
                        id="client"
                        name="nodedwith"
                        onChange={(e) => setNodedWith(e.target.value)}
                        placeholder="Select in the menu"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>
                    <div className="col-sm-12 mb-3">
                      <p className="mt-2">Notes</p>
                      <FancyInput
                        sMargin
                        textArea
                        id="notes"
                        type="text"
                        name="note"
                        onChange={inputChangeHandler}
                        placeholder="Add notes on this Appointment"
                      />
                    </div>
                  </div>
                </div>
                <div className="col-lg-7">
                  <div className="row gy-5">
                    <div className="col-sm-6 d-flex align-items-center justify-content-center">
                      <div
                        className="mt-5 clickalbe-car"
                        src="./assets/vectors/ar.svg"
                        alt="car"
                        onClick={addCircle}
                      >
                        {circles}
                      </div>
                    </div>
                    <div className="col-sm-6">
                      <h3 className="section-title">Appointment Landmarks</h3>
                      <div className="car-work-details emboss-white p-3 br-16 px-3 mt-4 pe-lg-5">
                        {appointments}
                      </div>

                      <div className="mt-5 d-flex justify-content-between">
                        <h3 className="section-title">
                          Service &amp; Articles
                        </h3>
                        <ModelServices
                          isOpen={servicesModalOpenState}
                          modalCloseHandler={() =>
                            modalCloseHandler(setServicesModalOpenState)
                          }
                        />
                        <AddBtn
                          small
                          pale
                          onClick={() =>
                            modalOpenHandler(setServicesModalOpenState)
                          }
                        />
                      </div>

                      <div className="table-container mt-3">
                        <table>
                          {Services.map((item) => (
                            <tr>
                              <td>
                                <div className="fs-12  text-light-5">
                                  {item.part}
                                </div>
                              </td>
                              <td>
                                <div className="fs-12 ">{item.partPrice}</div>
                              </td>
                              <td className="text-end" width={30}>
                                <img
                                  src="./assets/vectors/delete.svg"
                                  alt="delete"
                                />
                              </td>
                            </tr>
                          ))}
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </form>
  );
};

export default ModalAppointment;
