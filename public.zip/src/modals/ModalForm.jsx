import React, { useState } from "react";

import Modal from "./Modal";

const ModalForm = (props) => {
  const [brakeForm, setbrakeForm] = useState("");
  const [inspectionForm, setInspectionForm] = useState("");
  const [batteryForm, setBatteryForm] = useState("");
  const brakeFormActive = () => {
    setbrakeForm("activeForm");
    setInspectionForm("");
    setBatteryForm("");
  };
  const inspectionFormActive = () => {
    setbrakeForm("");
    setInspectionForm("activeForm");
    setBatteryForm("");
  };
  const batteryFormActive = () => {
    setbrakeForm("");
    setInspectionForm("");
    setBatteryForm("activeForm");
  };
  return (
    <div>
      <Modal
        titleVector="./assets/vectors/modal-forms.svg"
        title="Forms"
        buttonText="Add"
        {...props}
      >
        <div className="form-modal-body">
          <div className={"item " + brakeForm} onClick={brakeFormActive}>
            <img src="./assets/vectors/form-img.svg" alt="form-img" />
            <div className="text-x-small dark">Brake Check</div>
          </div>
          <div
            className={"item " + inspectionForm}
            onClick={inspectionFormActive}
          >
            <img src="./assets/vectors/form-img.svg" alt="form-img" />
            <div className="text-x-small dark">Inspection</div>
          </div>
          <div className={"item " + batteryForm} onClick={batteryFormActive}>
            <img src="./assets/vectors/form-img.svg" alt="form-img" />
            <div className="text-x-small dark">Battery Volt</div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ModalForm;
