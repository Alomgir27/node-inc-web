import React from "react";

//Creating context and give default value
export const AuthContext = React.createContext({
  tokens: {},
  user: {},
  setTokens: () => {},
  setUser: () => {},
});
//Provide context value
const AuthContextProvider = ({ children }) => {
  const [tokens, setTokens] = React.useState({});
  const [user, setUser] = React.useState({});
  return (
    <AuthContext.Provider value={{ tokens, setTokens, user, setUser }}>
      {children}
    </AuthContext.Provider>
  );
};

export default AuthContextProvider;
