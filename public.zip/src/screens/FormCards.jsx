import React, { useState } from "react";

import AddBtn from "../components/AddBtn";
import Input from "../components/Input";
import MainLayout from "../layouts/MainLayout";
import Tabs from "../components/Tabs";
import { BASEURL, sendNetworkRequest } from "../http/http-request";

const FormCards = () => {
  const [cardSelected, setCardSelected] = useState(false);
  const [textFields, setTextFields] = useState([]);
  const [submitting, setFormSubmission] = useState(false);
  const [numberFields, setNumberFields] = useState([]);
  const [formState, setFormState] = useState({
    label: "jmait",
    note_id: "",
    due_date: "",
    name:"",
  });

  const inputChangeHandler = (e) => {
    const { name, value } = e.target;

    setFormState((prevVal) => {
      return { ...prevVal, [name]: value };
    });
  };
  const createForm = async function createForm(event){
    event.preventDefault();
    setFormSubmission(true);
    try {
      const {label, due_date, note_id, name} = formState
       sendNetworkRequest(`${BASEURL}/form`, 'POST',{
        "is_internal": true,
        "name": name,
        "note_id": note_id,
        "due_date": new Date(due_date),
        "label": label
       }).then((res)=>{
         if(res.status==201){
          setFormSubmission(false)
          alert('Form successfully submitted');
         }
       }).catch((err)=>{
        setFormSubmission(false)
         alert('Form not successfully submitted');
         console.log(err.response.data)
       })
    } catch (error) {
      setFormSubmission(false)
    }
  }

  
  const addTextField = () => {
    const newField = (
      <div>
        <input
          className="text-dark-3 fs-14 pt-2 pb-2 fw-600 bg-transparent border-0"
          type="text"
          defaultValue="Label"
          onChange={() => {}}
        />
        <Input
          withToggler
          id="text"
          name="name"
          onChange={inputChangeHandler}
          placeholder=""
          handelDelete={deletetextField}
        />
      </div>
    );
    let allTextFields = [...textFields, newField];
    setTextFields(allTextFields);
  };
  const addNumberField = () => {
    const newNumberField = (
      <div>
        <input
          className="text-dark-3 fs-14 pt-2 pb-2 fw-600 bg-transparent border-0"
          type="text"
          defaultValue="Number"
          onChange={() => {}}
        />
        <Input
          Id={numberFields.length + 1}
          withToggler
          icon="vectors/calender-2.svg"
          id="number"
          name="number"
          onChange={inputChangeHandler}
          placeholder=""
          handelDelete={deleteNumberField}
        />
      </div>
    );
    let allNumberFields = [...numberFields, newNumberField];
    setNumberFields(allNumberFields);
  };
  const deletetextField = (e) => {
    textFields.splice(e.target.id, 1);
    setTextFields(textFields);
  };
  const deleteNumberField = (e) => {
    numberFields.splice(e.target.id, 1);
    setNumberFields(numberFields);
  };

  return (
    <MainLayout
      headVector="./assets/vectors/builder.svg"
      sideNavVector="./assets/vectors/builder.svg"
      title="Forms"
      activeLink="manner"
      tabData={{
        img: true,
        tabGroupName: "manner-tabs",
        data: [
          {
            icon: "./assets/vectors/form-notactive.svg",
            iconActive: "./assets/vectors/form-active.svg",
            target: "form",
            active: true,
          },
        ],
      }}
    >
      {cardSelected ? (
          <form action="" onSubmit={createForm}>
            <div id="form-builder-main-content" className="mt-4 mt-sm-0">
          <div className="container-fluid">
            <div className="row g-4">
              <div className="col-lg-8 col-md-6">
                <div className="form-builder mt-5">
                  <div className="head">
                    <div className="title">
                      <h3 className="section-title">Form name</h3>
                      <div className="text-manrope fw-400 mt-2">
                        Brake Inspection
                      </div>
                    </div>
                    <div className="node">
                      <div className="fw-600">Node with</div>
                    </div>
                  </div>
                  <div className="body">
                    <div className="emboss-white">
                      <Input
                        withToggler
                        fileUpload
                        label="Picture of Problem"
                        id="file"
                        name="file"
                        onChange={inputChangeHandler}
                        value={formState.file}
                      />
                      {textFields}
                      {numberFields}
                      <Input
                        withToggler
                        icon="vectors/calender-2.svg"
                        label="Next Due date"
                        // type="date"
                        id="date"
                        name="due_date"
                        onChange={inputChangeHandler}
                        value={formState.due_date}
                      />
                      <Input
                        withToggler
                        defaultTogglerClose
                        textArea
                        label="Notes"
                        id="notes"
                        name="notes"
                        onChange={inputChangeHandler}
                        value={formState.notes}
                        rows="8"
                      />
                    </div>

                    <div className="d-flex justify-content-end mt-5">
                      <button className="btn btn-gradient">{submitting?'Please wait':`Save & Return`}</button>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-lg-4 col-md-6 composents-container">
                <div className="card bordered px-0">
                  <h3 className="section-title mb-4">Composents</h3>

                  <div className="sections-wrap br-16 p-4">
                    <div className="sections br-16">
                      <div className="section">
                        <div className="imgs">
                          <img
                            src="./assets/vectors/composents-1.svg"
                            alt="composents"
                            onClick={addTextField}
                            className="hover"
                          />
                          <img
                            src="./assets/vectors/composents-2.svg"
                            alt="composents"
                            onClick={addNumberField}
                            className="hover"
                          />
                        </div>
                      </div>
                      <div className="section">
                        <div className="fw-600">CHOICES</div>
                        <div className="imgs">
                          <div className="img">
                            <div className="text">Single Choice</div>
                            <img
                              src="./assets/vectors/composents-3.svg"
                              alt="composents"
                            />
                          </div>
                          <div className="img">
                            <div className="text">Dropdown</div>
                            <img
                              src="./assets/vectors/composents-4.svg"
                              alt="composents"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="section">
                        <div className="fw-600">MULTIMEDIA</div>
                        <div className="imgs">
                          <div className="img">
                            <div className="text">Photo</div>
                            <img
                              src="./assets/vectors/composents-5.svg"
                              alt="composents"
                            />
                          </div>
                        </div>
                      </div>
                      <div className="section">
                        <div className="fw-600">DATE</div>
                        <div className="imgs">
                          <img
                            src="./assets/vectors/composents-6.svg"
                            alt="composents"
                          />
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
          </form>
      ) : (
        <div id="form-cards-main-content" className="mt-4 mt-sm-0">
          <div className="container-fluid px-0">
            <div className="row g-4">
              <div className="col">
                <div className="px-md-5 px-3">
                  <div className="d-flex justify-content-between align-items-center">
                    {/* <Tabs
                      tabClassName="mb-4 mb-sm-0 fw-600 text-poppins fs-14"
                      className="mt-4 "
                      tabGroupName="form-cards-tabs"
                      data={[
                        {
                          icon: "./assets/vectors/internal.svg",
                          iconActive: "./assets/vectors/internal.svg",
                          label: "Internal",
                          target: "internal",
                          active: true,
                        },
                        {
                          icon: "./assets/vectors/sms.svg",
                          iconActive: "./assets/vectors/sms-active.svg",
                          label: "Public",
                          target: "public",
                        },
                      ]}
                    />
                    <AddBtn /> */}
                  </div>

                  <div className="cards-container mt-5">
                    <div className="row gy-5 gx-xxl-5">
                      {[
                        {
                          title: "Brake Check",
                          questions: 4,
                        },
                        {
                          title: "Inspection",
                          questions: 28,
                        },
                        {
                          title: "AC Check",
                          questions: 4,
                        },
                        {
                          title: "Battery Volt.",
                          questions: 4,
                        },
                        {
                          title: "Label",
                          questions: 2,
                        },
                        {
                          title: "Add note",
                          questions: 3,
                        },
                        {
                          title: "Road Test",
                          questions: 14,
                        },
                        {
                          title: "Report",
                          questions: 7,
                        },
                        {
                          title: "Inspection",
                          questions: 28,
                        },
                      ].map((el, idx) => {
                        const { title, questions } = el;

                        return (
                          <div
                            key={"form-card" + idx}
                            className="col-lg-3 col-md-4 col-sm-6"
                          >
                            <div className="card emboss-white br-16 py-5 form-card">
                              <div className="main">
                                <div className="d-flex checkboxes">
                                  <label className="checkbox-container-2">
                                    Internal
                                    <input name="rd" type="radio" />
                                    <span className="checkmark"></span>
                                  </label>
                                  <label className="checkbox-container-2">
                                    Public
                                    <input name="rd" type="radio" />
                                    <span className="checkmark"></span>
                                  </label>
                                </div>
                                <h3
                                  className="section-title"
                                  onClick={() => setCardSelected(true)}
                                >
                                  {title}
                                </h3>
                                <div className="text-manrope mt-1 pb-3">
                                  {questions} questions
                                </div>
                                {/* <button
                                  className="btn btn-grey"
                                  onClick={() => setCardSelected(true)}
                                >
                                  Update
                                </button> */}
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  );
};

export default FormCards;
