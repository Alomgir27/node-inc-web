import React, { useEffect, useState } from "react";
import clsx from "clsx";

import MainLayout from "../layouts/MainLayout";
import TabContents from "../components/TabContents";
import TabContentItem from "../components/TabContentItem";
import AddBtn from "../components/AddBtn";
import ModalLifeActivity from "../modals/ModalLifeActivity";
import ModalOrder from "../modals/ModalOrder";
import ModalProfile from "../modals/ModalProfile";
import ModalAppointment from "../modals/ModalAppointment";
// import ModalForm from "../modals/ModalForm";
import ModalClinte from "../modals/ModalClient";
import axios from "axios";
import { genderResolver } from "../utils/genderResolver";
import Loader from "../components/Loader";

const ClientsList = () => {
  const [activityOpenState, setActivityOpenState] = useState(false);
  const [orderModalOpenState, setOrderModalOpenState] = useState(false);
  const [clinteModalOpenState, setClinteModalOpenState] = useState(false);
  const [clientSelected, setClientSelected] = useState(false);
  const [profileModalOpenState, setProfileModalOpenState] = useState(false);
  const [appointmentModalOpenState, setAppointmentModalOpenState] =
    useState(false);

  const [signedInUser, setSignedInUser] = useState(null);

  const [singleClient, setSingleClient] = useState(null);
  const [userConnections, setUserConnections] = useState([]);
  const [serviceSheets, setServiceSheets] = useState(null);
  const [invoices, setInvoices] = useState(null);
  const [userProfiles, setUserProfiles] = useState(null);
  const [activeProfile, setActiveProfile] = useState(null);
  const [newClient, setNewClient] = useState(false);

  console.log(userProfiles, "userProfiles");

  const modalOpenHandler = (func) => func(true);
  const modalCloseHandler = (func) => func(false);

  const handleActiveProfile = (el) => {
    console.log(el.id);
    // console.log(JSON.stringify(el, null, 2));
    el.object_id.parsedData = JSON.parse(el.object_id.data);
    setActiveProfile(el);
  };
  useEffect(() => {
    const tokens = JSON.parse(localStorage.getItem("tokens"));
    const loadConnections = async () => {
      const res = await axios({
        method: "GET",
        headers: {
          Authorization: `Bearer ${tokens.accessToken}`,
          refresh_token: tokens.refreshToken,
          idToken: tokens.idToken,
        },
        url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/users/me`,
      });

      setSignedInUser(res.data.user);

      try {
        if (signedInUser.id) {
          const response = await fetch(
            `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/users/connections/${signedInUser?.id}/0`,
            {
              method: "GET",
              headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${tokens.accessToken}`,
                idToken: tokens.idToken,
                refresh_token: tokens.refreshToken,
              },
            }
          );

          const connectionsData = await response.json();
          setUserConnections(connectionsData.connections);
          console.log(connectionsData.connections);
        }
      } catch (error) {
        console.log(error);
      }
    };
    loadConnections();
  }, [signedInUser?.id, newClient]);

  useEffect(() => {
    const tokens = JSON.parse(localStorage.getItem("tokens"));
    const fetchData = async () => {
      try {
        const res = await axios({
          method: "GET",
          headers: {
            Authorization: `Bearer ${tokens.accessToken}`,
            refresh_token: tokens.refreshToken,
            idToken: tokens.idToken,
          },
          url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/invoice/all/specific-entity/service/${singleClient.entityId}`,
        });
        setServiceSheets(
          res.data.invoices.length > 0 ? res.data.invoices : null
        );
        const resInvoice = await axios({
          method: "GET",
          headers: {
            Authorization: `Bearer ${tokens.accessToken}`,
            refresh_token: tokens.refreshToken,
            idToken: tokens.idToken,
          },
          url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/invoice/all/specific-entity/invoice/${singleClient.entityId}`,
        });
        console.log(
          `Invoices: ${JSON.stringify(resInvoice.data.invoices, null, 2)}`
        );
        setInvoices(
          resInvoice.data.invoices.length > 0 ? resInvoice.data.invoices : null
        );

        const resProfiles = await axios({
          method: "GET",
          headers: {
            Authorization: `Bearer ${tokens.accessToken}`,
            refresh_token: tokens.refreshToken,
            idToken: tokens.idToken,
          },
          url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/profile/single-user/profile/all/${singleClient.entityId}`,
        });
        // console.log(JSON.parse(resProfiles.data[0].object_id.data));
        setUserProfiles(resProfiles.data);
        handleActiveProfile(resProfiles.data[0]);
      } catch (error) {
        console.log(error);
      }
    };
    if (singleClient) fetchData();
  }, [singleClient]);

  return (
    <MainLayout
      headVector="./assets/vectors/way-connect.svg"
      title="Users"
      lightBorder
      activeLink="connect"
      tabData={
        clientSelected && {
          img: true,
          tabGroupName: "client-overview-tabs",
          data: [
            {
              icon: "./assets/vectors/np_user_active.svg",
              iconActive: "./assets/vectors/np_user.svg",
              target: "profile",
              active: true,
            },
            {
              icon: "./assets/vectors/profile.svg",
              iconActive: "./assets/vectors/profile-active.svg",
              target: "invoices",
            },
            {
              icon: "./assets/vectors/requests.svg",
              iconActive: "./assets/vectors/requests-active.svg",
              target: "requests",
            },
          ],
        }
      }
    >
      <ModalLifeActivity
        isOpen={activityOpenState}
        modalCloseHandler={() => modalCloseHandler(setActivityOpenState)}
      />
      <ModalOrder
        isOpen={orderModalOpenState}
        modalCloseHandler={() => modalCloseHandler(setOrderModalOpenState)}
      />
      <ModalClinte
        isOpen={clinteModalOpenState}
        modalCloseHandler={() => modalCloseHandler(setClinteModalOpenState)}
        headClassName="clintemodal-head"
        setNewClient={setNewClient}
      />
      {clientSelected ? (
        <div id="client-overview-main-content" className="mt-4 mt-sm-0">
          <div className="container-fluid">
            <div className="row g-4">
              <div className="col-md-9 col-sm-7 d-flex flex-column user-jumbotron-container">
                <div className="user-jumbotron-wrap flex-grow-1">
                  <div className="user-jumbotron h-100">
                    {singleClient.connection.connection_id.is_active && (
                      <div className="top d-flex align-items-start">
                        <img
                          src="./assets/vectors/lock-lg.svg"
                          className="lock me-2"
                          alt="lock"
                        />
                        <div className="text-blue text-manrope fs-10">
                          Unnode to edit Client
                        </div>
                      </div>
                    )}
                    <div className="profile-info">
                      <div className="left">
                        <div className="img">
                          <img
                            src={
                              singleClient.human_identity_id.gender === 0
                                ? "./assets/img/boyDefault.png"
                                : "./assests/img/girlDefault.png"
                            }
                            // src={singleClient.profilePic?.file_id?.link}
                            alt="client-img"
                            width="100%"
                          />
                          {singleClient.connection.connection_id.is_active && (
                            <div className="badge">Noded</div>
                          )}
                        </div>
                        <div className="social">
                          <button className="btn">
                            <img
                              className="social_icons"
                              src="./assets/vectors/np_phone.svg"
                              alt="profile"
                            />
                          </button>
                          <button className="btn">
                            <img
                              className="social_icons"
                              src="./assets/vectors/np_email.svg"
                              alt="profile"
                            />
                          </button>
                          <button className="btn">
                            <img
                              className="social_icons"
                              src="./assets/vectors/np_map.svg"
                              alt="profile"
                            />
                          </button>
                        </div>
                      </div>
                      <div className="right">
                        <div className="d-flex justify-content-start align-items-start flex-md-row flex-column justify-content-md-between">
                          <div>
                            <div className="user-name d-flex align-items-center">
                              <h4 className="evidence-word text-blue">
                                {singleClient.human_identity_id.middle_name ===
                                null
                                  ? `${singleClient.human_identity_id.first_name} ${singleClient.human_identity_id.last_name}`
                                  : `${singleClient.human_identity_id.first_name} ${singleClient.human_identity_id.middle_name} ${singleClient.human_identity_id.last_name}`}
                              </h4>
                              <img
                                src="./assets/vectors/verified.svg"
                                className="ms-4"
                                alt="verified"
                              />
                            </div>
                            <div className="location">
                              <div className="text-manrope fw-400">
                                {singleClient.address_id === null
                                  ? `Sorry! User does have a address yet`
                                  : `${singleClient.address_id.address_line_1} ${singleClient.address_id.address_line_2}`}
                              </div>
                            </div>
                          </div>
                          <button
                            onClick={() =>
                              modalOpenHandler(setActivityOpenState)
                            }
                            className="btn btn-blue-high  ms-0 mt-md-0 mt-3 d-flex align-items-center justify-content-center"
                          >
                            View History
                          </button>
                        </div>

                        <div className="container-fluid px-0 mt-4 pt-2">
                          <div className="row gx-0 gy-4">
                            <div className="col-md-8">
                              <div className="text-bold">
                                {`${singleClient.email_id.contact}@${singleClient.email_id.domain}`}
                              </div>
                              <h5 className="sub-title text-light-2">Email</h5>
                            </div>
                            <div className="col-md-4">
                              <div className="text-bold">
                                {" "}
                                {singleClient.phone === null
                                  ? `No phone number!`
                                  : singleClient.phone.phone_number_id.number}
                              </div>
                              <h5 className="sub-title text-light-2">Phone</h5>
                            </div>
                            <div className="col-md-8">
                              <div className="row gy-4">
                                <div className="col-md-6">
                                  <div className="text-bold">{`${new Date(
                                    singleClient.human_identity_id.DOB
                                  ).getMonth()}/${new Date(
                                    singleClient.human_identity_id.DOB
                                  ).getDate()}/${new Date(
                                    singleClient.human_identity_id.DOB
                                  ).getFullYear()}`}</div>
                                  <h5 className="sub-title text-light-2">
                                    DOF
                                  </h5>
                                </div>
                                <div className="col-md-6">
                                  <div className="text-bold">Title</div>
                                  <h5 className="sub-title text-light-2">
                                    Cook
                                  </h5>
                                </div>
                              </div>
                            </div>
                            <div className="col-md-4">
                              <div className="text-bold">Sexe</div>
                              <h5 className="sub-title text-light-2">
                                {
                                  genderResolver[
                                    singleClient.human_identity_id.gender
                                  ]
                                }
                              </h5>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-md-3 col-sm-5 garage-specs-container">
                <div className="card garage-card">
                  <img src="./assets/vectors/garage.svg" alt="garage" />
                  <h3 className="section-title mt-2">Garage Specs</h3>
                  <div className="text-x-small mt-2 mb-3 desc-p">
                    Based on customer responses and Node's artificial
                    intelligence
                  </div>

                  <div className="section">
                    <div className="text-x-bold">A lot (50 000km) a year</div>
                    <div className="text-x-small">Travel</div>
                  </div>
                  <div className="section">
                    <div className="text-x-bold">Countryside</div>
                    <div className="text-x-small">Reside</div>
                  </div>
                  <div className="section">
                    <div className="text-x-bold">
                      Origin of the manufacturer
                    </div>
                    <div className="text-x-small">Preferred parts</div>
                  </div>
                  <div className="section">
                    <div className="text-x-bold">6 times a year minimum</div>
                    <div className="text-x-small">Frequency</div>
                  </div>
                </div>
              </div>
              <div className="col-12"></div>
              <div className="col-12">
                <TabContents tabGroupName="client-overview-tabs mt-5">
                  <TabContentItem target="profile">
                    <div className="container-fluid px-0">
                      <div className="row gx-lg-5 gy-5">
                        <div className="col-lg-4">
                          <div className="last-work-orders">
                            <div className="d-flex justify-content-between title-container">
                              <div className="title">
                                <h3 className="section-title text-dark-1">
                                  Cards
                                </h3>
                              </div>
                              <ModalAppointment
                                isOpen={appointmentModalOpenState}
                                modalCloseHandler={() =>
                                  modalCloseHandler(
                                    setAppointmentModalOpenState
                                  )
                                }
                              />
                              <AddBtn
                                title="NEW"
                                blue
                                onClick={() =>
                                  modalOpenHandler(setAppointmentModalOpenState)
                                }
                              />
                            </div>
                            <div className="emboss-white br-16 mt-2 ">
                              <div className="listing-container short-vertical-scrollbar">
                                <div className="listing mt-3">
                                  {serviceSheets ? (
                                    serviceSheets.map((invoice) => (
                                      <div
                                        key={invoice.id}
                                        className="list-item"
                                      >
                                        <div className="order-num d-flex align-items-center">
                                          <div
                                            className="round-box"
                                            style={{
                                              backgroundColor: "#7E8876",
                                            }}
                                          ></div>
                                          <div className="text-dark-2">
                                            {invoice.id}
                                          </div>
                                        </div>
                                        <div className="order-date">
                                          <div className="text-light-4">
                                            {`${new Date(
                                              invoice.invoice_date
                                            ).getFullYear()}-${
                                              new Date(
                                                invoice.invoice_date
                                              ).getMonth() + 1
                                            }-${new Date(
                                              invoice.invoice_date
                                            ).getDate()}`}
                                          </div>
                                        </div>
                                        <div className="order-price">
                                          <div className="">
                                            {invoice.subtotal}$
                                          </div>
                                        </div>
                                      </div>
                                    ))
                                  ) : (
                                    <div
                                      className="text-center"
                                      style={{ padding: "10px" }}
                                    >
                                      <h3 className="text-light-2">
                                        No service sheets yet!
                                      </h3>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-8 profiles-container">
                          <div className="d-flex justify-content-between title-container">
                            <div className="title ps-4">
                              <h3 className="section-title text-dark ps-0">
                                Profiles
                              </h3>
                            </div>
                            <ModalProfile
                              isOpen={profileModalOpenState}
                              modalCloseHandler={() =>
                                modalCloseHandler(setProfileModalOpenState)
                              }
                              user={signedInUser}
                              setUserProfiles={setUserProfiles}
                              currentUser={singleClient}
                            />
                            <AddBtn
                              title="NEW"
                              blue
                              onClick={() =>
                                modalOpenHandler(setProfileModalOpenState)
                              }
                            />
                          </div>

                          <div className="profiles-main  mt-2">
                            <div className="left">
                              {userProfiles &&
                                userProfiles.map((el) => {
                                  const data = JSON.parse(el.object_id.data);

                                  return (
                                    <div
                                      className="items mb-3"
                                      onClick={() => handleActiveProfile(el)}
                                    >
                                      <div
                                        key={"prod-list" + el.id}
                                        className={clsx(
                                          "item br-10 d-flex align-items-center",
                                          {
                                            active: activeProfile?.id === el.id,
                                          },
                                          {
                                            "emboss-md-inner":
                                              el.id == activeProfile.id
                                                ? true
                                                : false,
                                          }
                                        )}
                                      >
                                        <div
                                          className="img"
                                          // style={{ backgroundColor: "" }}
                                        >
                                          <img
                                            src={
                                              "/assets/vectors/toyota-prius-prime.svg"
                                            }
                                            alt={data.name}
                                          />
                                        </div>
                                        <div className="text">
                                          <div className="text-dark-3 fw-600">
                                            {data.name}
                                          </div>
                                          <h5 className="sub-title">
                                            {data.serial}
                                          </h5>
                                          <div className="text-dark-3 fw-400 fs-7 text-manrope d-flex align-items-center">
                                            {el.is_active &&
                                              "Noded & Validated"}
                                            {el.is_active && (
                                              <img
                                                className="ms-2"
                                                src="./assets/vectors/validated.svg"
                                                alt="validated"
                                              />
                                            )}
                                          </div>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                            </div>
                            <div className="right emboss-white  br-16 p-4">
                              {activeProfile && (
                                <>
                                  <div className="head">
                                    <div className="d-flex justify-content-between">
                                      <div className="fs-20 text-blue fw-200 text-manrope mb-3">
                                        {
                                          activeProfile.object_id.parsedData
                                            .name
                                        }
                                      </div>

                                      <div
                                        className="d-flex align-items-start text-blue text-manrope fw-400 fs-12 me-sm-4"
                                        style={{ maxWidth: "70px" }}
                                      >
                                        <img
                                          className="mt-1 me-2"
                                          src="./assets/vectors/noded-blue.svg"
                                          alt="noded"
                                        />
                                        Noded &amp; Validated
                                      </div>
                                    </div>
                                    <div className="fs-10 text-xx-small">
                                      Attribute
                                    </div>
                                  </div>

                                  <div className="container-fluid px-0">
                                    <div className="row">
                                      <div className="section mb-2">
                                        <div className="text-light-5 text-manrope">
                                          Vechicle Serial Number (VIN)
                                        </div>
                                        <div className="text-dark-3 fw-600">
                                          {
                                            activeProfile.object_id.parsedData
                                              .serial
                                          }
                                        </div>
                                      </div>
                                      <div className="section mb-2">
                                        <div className="text-light-5 text-manrope">
                                          Official Name - Garage ecosystem
                                        </div>
                                        <div className="text-dark-3 fw-600">
                                          {
                                            activeProfile.object_id.parsedData
                                              .name
                                          }
                                        </div>
                                      </div>
                                      <div className="section mb-2">
                                        <div className="text-light-5 text-manrope">
                                          Engine
                                        </div>
                                        <div className="text-dark-3 fw-600">
                                          {
                                            activeProfile.object_id.parsedData
                                              .engine
                                          }
                                        </div>
                                      </div>
                                      <div className="container-fluid px-3">
                                        <div className="row">
                                          <div className="col-sm-4 col-6">
                                            <div className="section">
                                              <div className="text-light-5 text-manrope">
                                                Odometer
                                              </div>
                                              <div className="text-dark-3 fw-600">
                                                298 km
                                                {/* {activeProfile.object_id
                                                  .parsedData.transmission ===
                                                ""
                                                  ? "Cannot find transmission data"
                                                  : activeProfile.object_id
                                                      .parsedData.transmission} */}
                                              </div>
                                              {/* <div className="text-light-5 text-manrope">
                                                Transmission
                                              </div>
                                              <div className="text-dark-3 fw-600">
                                                {activeProfile.object_id
                                                  .parsedData.transmission ===
                                                ""
                                                  ? "Cannot find transmission data"
                                                  : activeProfile.object_id
                                                      .parsedData.transmission}
                                              </div> */}
                                            </div>
                                          </div>
                                          <div className="col-sm-4 col-6">
                                            <div className="section">
                                              <div className="text-light-5 text-manrope">
                                                Tires
                                              </div>
                                              <div className="text-dark-3 fw-600">
                                                {
                                                  activeProfile.object_id
                                                    .parsedData.tire
                                                }
                                              </div>
                                            </div>
                                          </div>
                                          <div className="col-sm-4 col-6">
                                            <div className="section">
                                              <div className="text-light-5 text-manrope">
                                                Plate
                                              </div>
                                              <div className="text-dark-3 fw-600">
                                                {
                                                  activeProfile.object_id
                                                    .parsedData.plate
                                                }
                                              </div>
                                            </div>
                                          </div>
                                        </div>
                                      </div>
                                    </div>

                                    <div className="btns d-flex flex-wrap flex-column flex-sm-row mt-3">
                                      <button className="bottom-btns-profile btn m-2 btn-emboss">
                                        <img
                                          id="1"
                                          src="./assets/vectors/scan.svg"
                                          alt="dollar"
                                          // onClick={HandelProfileBottomBtns}
                                          width="40%"
                                        />
                                      </button>
                                      <ModalAppointment
                                        isOpen={appointmentModalOpenState}
                                        modalCloseHandler={() =>
                                          modalCloseHandler(
                                            setAppointmentModalOpenState
                                          )
                                        }
                                      />
                                      <button
                                        className="bottom-btns-profile btn m-2 btn-emboss"
                                        onClick={() =>
                                          modalOpenHandler(
                                            setProfileModalOpenState
                                          )
                                        }
                                      >
                                        <img
                                          id="2"
                                          src="./assets/vectors/editblue.svg"
                                          alt="dollar"
                                          width="40%"
                                        />
                                      </button>
                                      <button className="bottom-btns-profile btn m-2 btn-emboss">
                                        <img
                                          id="3"
                                          src="./assets/vectors/userlink.svg"
                                          alt="dollar"
                                          width="40%"
                                          // onClick={HandelProfileBottomBtns}
                                        />
                                      </button>
                                      <button className="bottom-btns-profile btn m-2 btn-emboss">
                                        <img
                                          src="./assets/vectors/clock.svg"
                                          alt="dollar"
                                          width="40%"
                                          // onClick={HandelProfileBottomBtns}
                                        />
                                      </button>
                                    </div>
                                  </div>
                                </>
                              )}
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabContentItem>
                  <TabContentItem target="invoices">
                    <div className="container-fluid p-0">
                      <div className="row gx-sm-5 gy-5">
                        <div className="col-lg-6 invoices-wrapper">
                          <div className="invoices-main">
                            <div className="d-flex justify-content-between title-container align-items-start">
                              <div className="title ps-3">
                                <h3 className="section-title">Invoices</h3>
                              </div>
                              <AddBtn blue title="NEW" />
                            </div>
                            <div className="emboss-white br-16">
                              <div className="listing-container">
                                <div className="listing">
                                  {invoices ? (
                                    invoices.map((invoice) => (
                                      <div
                                        className="list-item"
                                        key={invoice.id}
                                      >
                                        <div className="order-num d-flex align-items-center">
                                          <div
                                            className="round-box"
                                            style={{
                                              backgroundColor: "#7E8876",
                                            }}
                                          ></div>
                                          <div className="text-dark-2">
                                            {invoice.id}
                                          </div>
                                        </div>
                                        <div className="order-date">
                                          <div className="text-light-4">
                                            {`${new Date(
                                              invoice.invoice_date
                                            ).getFullYear()}-${
                                              new Date(
                                                invoice.invoice_date
                                              ).getMonth() + 1
                                            }-${new Date(
                                              invoice.invoice_date
                                            ).getDate()}`}
                                          </div>
                                        </div>
                                        <div className="order-price price-1">
                                          <div className="">
                                            {invoice.subtotal}$
                                          </div>
                                        </div>
                                        <div className="order-price">
                                          {/* <div className="price-text">
                                            {price2}$ */}
                                          {/* <div className="price-sign">
                                            <img
                                              src="./assets/vectors/dollar-sign.svg"
                                              alt="dollar"
                                            />
                                          </div> */}
                                          {/* </div> */}
                                        </div>
                                      </div>
                                    ))
                                  ) : (
                                    <div
                                      className="text-center"
                                      style={{ padding: "10px" }}
                                    >
                                      <h3 className="text-light-2">
                                        No invoices yet!
                                      </h3>
                                    </div>
                                  )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-6">
                          <div className="forms-main">
                            <div className="d-flex justify-content-between title-container">
                              <div className="title ps-3">
                                <h3 className="section-title ">
                                  Forms &amp; Files
                                </h3>
                              </div>
                              <AddBtn blue />
                            </div>
                            <div className="emboss-white br-16">
                              <div className="listing-container short-vertical-scrollbar">
                                <div className="listing">
                                  {/* {[
                                    {
                                      label: "Inspection",
                                      name: "WO #893788784",
                                      date: "2021-10-22",
                                    },
                                    {
                                      label: "Note",
                                      name: "WO #893788784",
                                      date: "2021-10-22",
                                    },
                                    {
                                      label: "Brake Photo",
                                      name: "photo-brake.jpg",
                                      date: "2021-10-22",
                                    },
                                    {
                                      label: "Inspection",
                                      name: "WO #893788784",
                                      date: "2021-10-22",
                                    },
                                    {
                                      label: "Scratch",
                                      name: "WO #893788784",
                                      date: "2021-10-22",
                                    },
                                    {
                                      label: "Outside verification",
                                      name: "WO #893788784",
                                      date: "2021-10-22",
                                    },
                                    {
                                      label: "Note",
                                      name: "WO #893788784",
                                      date: "2021-10-22",
                                    },
                                  ].map((el, idx) => {
                                    const { label, name, date } = el; */}

                                  {invoices &&
                                    invoices.map(
                                      (invoice) =>
                                        invoice.invoice_file_id && (
                                          <>
                                            <div
                                              className="list-item"
                                              key={"ins" + invoice.id}
                                            >
                                              <div className="label">
                                                <div className="text-dark-2">
                                                  {invoice.metadata.name}
                                                </div>
                                              </div>
                                              <div className="name text-light-4">
                                                {invoice.invoice_file_id.id}
                                              </div>
                                              <div className="date">
                                                <div className="font-manrope text-end">
                                                  {`${new Date(
                                                    invoice.invoice_date
                                                  ).getFullYear()}-${
                                                    new Date(
                                                      invoice.invoice_date
                                                    ).getMonth() + 1
                                                  }-${new Date(
                                                    invoice.invoice_date
                                                  ).getDate()}`}
                                                </div>
                                              </div>
                                            </div>
                                          </>
                                        )
                                    )}
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabContentItem>
                  <TabContentItem target="requests">
                    <div className="container-fluid px-0 ">
                      <div className="row">
                        <div className="col-lg-7 requests-container">
                          <div className="d-flex justify-content-between title-container">
                            <div className="title">
                              <h3 className="section-title">Requests</h3>
                            </div>
                            <AddBtn blue title="NEW" />
                          </div>
                          <div className="emboss-white br-16 ps-4 pe-4">
                            <div className="requests-list-container short-vertical-scrollbar">
                              <div className="requests-list mt-4">
                                {[
                                  {
                                    incoming: true,
                                    titleText: "Appointment 12/01/2022",
                                    boxClr: "#5165F7",
                                    category: 3,
                                    date: "Due in 2 days",
                                  },
                                  {
                                    incoming: false,
                                    titleText: "Call To FLW UP",
                                    boxClr: "#5197F8",
                                    category: 3,
                                    date: "Due in 7 days",
                                  },
                                  {
                                    incoming: true,
                                    titleText: "Appointment 02/12/2021",
                                    boxClr: "#FA8036",
                                    category: 3,
                                    date: "Done 7 days ago",
                                  },
                                ].map((el, idx) => {
                                  const {
                                    titleText,
                                    date,
                                    category,
                                    incoming,
                                  } = el;

                                  return (
                                    <div
                                      className="requests-list-item c-pointer"
                                      key={"req-list" + idx}
                                      onClick={() =>
                                        modalOpenHandler(setOrderModalOpenState)
                                      }
                                    >
                                      <div className="mini-info">
                                        <img
                                          src={
                                            incoming
                                              ? "./assets/vectors/incoming-request.svg"
                                              : "./assets/vectors/outgoing-request.svg"
                                          }
                                          className="me-3"
                                          alt="request-accept"
                                        />
                                        <div className="text-dark-2">
                                          {titleText}
                                        </div>
                                      </div>
                                      <div className="more-info">
                                        <div className="todo d-flex align-items-center">
                                          <div
                                            className="round-box me-2"
                                            style={{
                                              backgroundColor: "#C26666",
                                            }}
                                          ></div>
                                          <div className="caption">To do</div>
                                        </div>
                                        <div className="prod-name">
                                          <h5 className="sub-title">
                                            Category {category}
                                          </h5>
                                        </div>
                                        <div className="date">
                                          <h5 className="sub-title">{date}</h5>
                                        </div>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </div>
                        <div className="col-lg-5 interactions-container mt-lg-0 mt-5">
                          <div className="d-flex justify-content-between title-container">
                            <div className="title">
                              <h3 className="section-title">Interactions</h3>
                            </div>
                          </div>
                          <div className="emboss-white br-16">
                            <div className="listing-container interactions-container short-vertical-scrollbar">
                              <div className="listing mt-0">
                                {[
                                  {
                                    titleText: "Email",
                                    date: "21 Sep 2021",
                                  },
                                  {
                                    titleText: "Phone",
                                    time: "00:01:32",
                                    date: "21 Sep 2021",
                                  },
                                ].map((el, idx) => {
                                  const { titleText, date, time } = el;

                                  return (
                                    <div
                                      className="list-item"
                                      key={"req-list" + idx}
                                    >
                                      <div className="text-dark-2">
                                        {titleText}
                                      </div>
                                      <div className="time">
                                        <h5 className="sub-title">{time}</h5>
                                      </div>
                                      <div className="date">
                                        <h5 className="sub-title">{date}</h5>
                                      </div>
                                    </div>
                                  );
                                })}
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </TabContentItem>
                </TabContents>
              </div>
            </div>
          </div>
        </div>
      ) : (
        <div id="client-list-main-content">
          <div className="container-fluid mt-3">
            <div className="w-100 d-flex justify-content-end">
              <AddBtn
                blue
                title="NEW"
                onClick={() => modalOpenHandler(setClinteModalOpenState)}
              />
            </div>
            <div className="row g-3 mt-3">
              {userConnections?.length > 0 ? (
                userConnections?.map((el, idx) => {
                  return (
                    <div
                      className="col-lg-3 col-md-4 col-sm-6 col-12"
                      key={"client-list" + idx}
                    >
                      <ClientCard
                        setClientSelected={setClientSelected}
                        entityId={
                          el.connection_id.target_entity_id.id ===
                          signedInUser.entity_id.id
                            ? el.entity_id.id
                            : el.connection_id.target_entity_id.id
                        }
                        setSingleClient={setSingleClient}
                        connection={el}
                      />
                    </div>
                  );
                })
              ) : (
                <div className="col-12 w-100 h-100 d-flex justify-content-center align-items-center loader-container">
                  <Loader />
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </MainLayout>
  );
};

export default ClientsList;

const ClientCard = ({
  entityId,
  setClientSelected,
  setSingleClient,
  connection,
}) => {
  const [user, setUser] = useState(null);
  const [profilePic, setProfilePic] = useState(null);

  useEffect(() => {
    const tokens = JSON.parse(localStorage.getItem("tokens"));
    const fetchData = async () => {
      try {
        const data = await axios({
          method: "GET",
          url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/users/entity/${entityId}`,
          headers: {
            Authorization: `Bearer ${tokens.accessToken}`,
            refresh_token: tokens.refreshToken,
            idToken: tokens.idToken,
          },
        });

        try {
          const profilePicture = await axios({
            method: "GET",
            url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/users/profile/picture/${data.data.id}`,
            headers: {
              Authorization: `Bearer ${tokens.accessToken}`,
              refresh_token: tokens.refreshToken,
              idToken: tokens.idToken,
            },
          });
          console.log(profilePicture.data);
          setProfilePic(profilePicture.data.picture);
        } catch (error) {
          console.log(error);
        }

        setUser(data.data);
      } catch (error) {
        console.log(error);
      }
    };
    fetchData();
  }, [entityId]);

  const handleClientClick = () => {
    setClientSelected(true);
    setSingleClient({ ...user, entityId, connection, profilePic });
  };

  return user ? (
    <div className="client-card emboss-md" onClick={() => handleClientClick()}>
      <div className="head">
        <div className="img" style={{ background: "#ECA0A0" }}>
          {/* {profilePic && (
            <img src={profilePic?.file_id?.link} alt={"Profile"} />
          )} */}
          <img
            src={
              user.human_identity_id.gender === 0
                ? "./assets/img/boyDefault.png"
                : "./assests/img/girlDefault.png"
            }
            alt={"Profile"}
          />
        </div>
        <div className="text">
          <h3 className="section-title">{`${
            user.human_identity_id.first_name || user.first_name
          } ${user.human_identity_id.last_name}`}</h3>
          <div className="text-small">
            {/* {visits} visit{visits > 1 && "s"} */}0 visits
          </div>
        </div>
      </div>
      <div className="body">
        <div className="section">
          <div className="text-small">Email</div>
          <div className="text-dark-4 fw-600">{`${user.email_id.contact}@${user.email_id.domain}`}</div>
        </div>
        <div className="section">
          <div className="text-small">Phone</div>
          <div className="text-dark-4 fw-600">
            {user.phone === null
              ? "User does not have phone yet"
              : user.phone.phone_number_id.number}
          </div>
        </div>
        <div className="section noded">
          {/* {noded && <button className="btn btn-vert">Noded</button>} */}
        </div>
      </div>
    </div>
  ) : (
    <p>Loading</p>
  );
};
