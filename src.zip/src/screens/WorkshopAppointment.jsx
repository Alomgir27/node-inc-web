import React, { useState, useEffect } from "react";
import WorkshopLayout from "../layouts/WorkshopLayout";
import AddBtn from "../components/AddBtn";
import Schedular from "../components/Schedular";
import ModalAppointment from "../modals/ModalAppointment";
import { BASEURL, sendNetworkRequest } from "../http/http-request";

const WorkshopAppointment = () => {
  const [appointmentModalOpenState, setAppointmentModalOpenState] =
    useState(false);
    const [employeeList, setEmployeeList] = useState([]);
    const [clientList, setCLientList] = useState([]);
    const [humanList, setHumanList] = useState([]);
  const modalOpenHandler = (func) => {
    func(true);
  };
       
  useEffect(()=>{
    sendNetworkRequest(`${BASEURL}/core/employees`)
    .then((response)=>{
      response.data.map((e)=>{
        const ef = [
          {
            text: 'Select in the menu',
            disabled: false,
            selected: true,
          },
        ]
        ef.push({
          text: e.human_identity_id.first_name + ' ' + ' '+ e.human_identity_id.last_name,
          disabled: false,
          selected: true,
        },)
       setEmployeeList(ef);
      })
    })
    .catch((err)=>{
     console.log(err);
    })
    sendNetworkRequest(`${BASEURL}/core/clients`, 'GET','')
    .then((response)=>{
    
     setHumanList(response.data);
   const   ef = [
    {
      text: 'Select in the menu',
      disabled: false,
      selected: true,
    },
   ]
      response.data.forEach((e, i)=>{
        ef.push({
          text: e.human_identity_id.first_name + ' ' + ' '+e.human_identity_id.last_name,
          value: e.entity_id.id,
          disabled: false,
          selected: true,
        },
        )
      
      })
      setCLientList(ef);
    })
    .catch((err)=>{
     console.log(err.response);
    })
 },[])

  const modalCloseHandler = (func) => {
    func(false);
  };
  return (
    <WorkshopLayout>
      <div className="appointment-container">
        <div className="d-flex justify-content-end align-items-center my-4">
          <h3 className="section-title">September7, 2022</h3>
          <img
            className="ms-4 me-5"
            src="./assets/vectors/calendar.svg"
            alt="calendar"
          />
          <AddBtn
            blue
            title="NEW"
            onClick={() => modalOpenHandler(setAppointmentModalOpenState)}
          />
        </div>
        <ModalAppointment
          isOpen={appointmentModalOpenState}
          employeeList={employeeList}
          clientList ={clientList}
          humanList={humanList}
          modalCloseHandler={() =>
            modalCloseHandler(setAppointmentModalOpenState)
          }
        />
        <div className="schedule-control-section-wrap">
          <Schedular />
        </div>

        <div className="week-load">
          <div className="left">
            <div className="ps-3">
              <h3 className="section-title">Week Load</h3>
              <div className="text-label fs-10 text-light-5 lh-1 mt-1">
                Click on the employee to see <br /> the details over a week
              </div>
            </div>
            <div className="selector">
              <div className="d-flex align-items-center">
                <div className="btn center-content p-0">
                  <img src="./assets/vectors/arrow-left-blue.svg" alt="arrow" />
                </div>
                <div className="tag text-blue text-lato fw-700 mx-1">
                  09-01 to 15-01
                </div>
                <div className="btn center-content p-0">
                  <img
                    src="./assets/vectors/arrow-right-blue.svg"
                    alt="arrow"
                  />
                </div>
              </div>
            </div>
          </div>
          <div className="right">
            <div className="load-main">
              {[
                {
                  size: "two",
                  number: 2,
                  userImg: "./assets/img/chat-me.png",
                },
                {
                  size: "two",
                  number: 2,
                  userImg: "./assets/img/chat-me.png",
                },
                {
                  size: "four",
                  number: 4,
                  userImg: "./assets/img/chat-me.png",
                },
                {
                  size: "two",
                  number: 2,
                  userImg: "./assets/img/chat-me.png",
                },
                {
                  size: "one",
                  number: 1,
                  userImg: "./assets/img/chat-me.png",
                },
                {
                  size: "two",
                  number: 2,
                  userImg: "./assets/img/chat-me.png",
                },
              ].map((el, idx) => {
                const { size, number, userImg } = el;

                return (
                  <div key={"load-item" + idx} className="item ">
                    <div className="number-wrap">
                      <div className={`number${size ? " " + size : ""}`}>
                        <div className="text">{number}</div>
                      </div>
                    </div>
                    <img src={userImg} alt="" />
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </WorkshopLayout>
  );
};

export default WorkshopAppointment;
