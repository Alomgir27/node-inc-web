import React from "react";

import Modal from "./Modal";
import AddBtn from "../components/AddBtn";
import FancyInput from "../components/FancyInput";

const ModalServices = (props) => {
  return (
    <div>
      <Modal
        className="profile-modal w-25"
        // titleVector="./assets/vectors/modal-article.svg"
        title="Service & Articles"
        buttonText="SAVE"
        {...props}
        headClassName="modalServices-head"
      >
        <div className="article-modal-body">
          <div className="container-fluid px-0">
            <div className="row">
              <div className="col-sm-12">
                <p className="mt-2">Search modal</p>
                <FancyInput
                  sMargin
                  id="Search modal"
                  name="Search modal"
                  placeholder="Start typing..."
                />
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ModalServices;
