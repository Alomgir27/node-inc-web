import React from "react";

import Modal from "./Modal";
import AddBtn from "../components/AddBtn";
import FancyInput from "../components/FancyInput";

const ModalArticle = (props) => {
  return (
    <div>
      <Modal
        className="article-modal"
        titleVector="./assets/vectors/modal-article.svg"
        title="Article"
        buttonText="SAVE"
        {...props}
      >
        <div className="article-modal-body">
          <p className="mt-2">Article's name</p>
          <FancyInput
            sMargin
            prominant
            id="articleName"
            name="articleName"
            placeholder="Start typing..."
          />

          <div className="container-fluid px-0">
            <div className="row">
              <div className="col-sm-6">
                <p className="mt-2"> SKU</p>
                <FancyInput
                  sMargin
                  prominant
                  id="sku"
                  name="sku"
                  placeholder="Start typing..."
                />
              </div>
              <div className="col-sm-6">
                <p className="mt-2"> Available quantity</p>
                <FancyInput
                  sMargin
                  prominant
                  id="availQuan"
                  name="availQuan"
                  placeholder="Start typing..."
                />
              </div>
              <div className="col-sm-6">
                <p className="mt-2">Detail Price</p>
                <FancyInput
                  sMargin
                  prominant
                  id="price"
                  name="price"
                  placeholder="Start typing..."
                />
              </div>
              <div className="col-sm-6">
                <p className="mt-2"> Category</p>
                <FancyInput
                  sMargin
                  prominant
                  id="category"
                  name="category"
                  placeholder="Select category"
                />
              </div>
              <div className="col-sm-6">
                <p className="mt-2"> Cost Price</p>
                <FancyInput
                  sMargin
                  prominant
                  id="costprice"
                  name="costprice"
                  placeholder="Start typing..."
                />
              </div>
              <div className="col-sm-6">
                <p className="mt-2"> Dimensions (W x H x L)</p>
                <FancyInput
                  sMargin
                  prominant
                  id="dimension"
                  name="dimension"
                  placeholder="Start typing..."
                />
              </div>
              <div className="col-sm-6">
                <p className="mt-2"> Waranty</p>
                <FancyInput
                  sMargin
                  prominant
                  id="waranty"
                  name="waranty"
                  placeholder="Start typing..."
                />
              </div>

              <div className="col-sm-6">
                <div className="d-flex align-items-start ">
                  <div className="w-75">
                    <p className="mt-2"> Attachments</p>
                    <FancyInput
                      sMargin
                      rootStyle={{ width: "100%" }}
                      prominant
                      type="file"
                      id="upload"
                      name="model"
                      // label="Attachments"
                      label2="Upload your picture"
                      placeholder="Type a Valide VIN"
                    />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ModalArticle;
