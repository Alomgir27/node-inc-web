import React, { useState } from "react";

import Modal from "./Modal";
import FancyInput from "../components/FancyInput";
import AddBtn from "../components/AddBtn";
import Input from "../components/Input";

const ModalRequests = (props) => {
  const [allSubTasks, setAllSubTasks] = useState([]);
  const [subTask, setSubTask] = useState();

  const handalAddSubTask = () => {
    setAllSubTasks([...allSubTasks, subTask]);
  };

  const deleteTask = (e) => {
    let tasks = allSubTasks.splice(e.target.id, e.target.id);
    setAllSubTasks(tasks);
  };

  console.log(allSubTasks, "asdf");
  return (
    <div>
      <Modal title="New Request" buttonText="Add" {...props}>
        <div className="row">
          <div className="col-sm-6">
            <p className="mt-2">Request Name</p>
            <FancyInput
              prominant
              sMargin
              id="vin"
              name="vin"
              placeholder="Start typing..."
              //   onChange={(e) => setSerial(e.target.value)}
            />
          </div>
          <div className="col-sm-6">
            <p className="mt-2">Due Date</p>
            <FancyInput
              sMargin
              id="date"
              type="date"
              name="sdate"
              //   onChange={inputChangeHandler}
              placeholder="DD/MM/AA   at 00:000"
              inputClassName="dateInput"
            />
          </div>

          <div className="col-sm-6">
            <p className="mt-2">Assign to</p>
            <FancyInput
              select
              options={[
                {
                  text: "Select the menu",
                  disable: true,
                  selected: true,
                },
              ]}
              id="client"
              name="nodedwith"
              placeholder="Select in the menu"
              rootClassName="appointment-select"
              inputClassName="custom-select"
            />
          </div>
          <div className="col-sm-6">
            <p className="mt-2">Type</p>
            <FancyInput
              select
              options={[
                {
                  text: "Select the menu",
                  disable: true,
                  selected: true,
                },
              ]}
              id="client"
              name="nodedwith"
              placeholder="Select in the menu"
              rootClassName="appointment-select"
              inputClassName="custom-select"
            />
          </div>
          <div className="col-sm-12">
            <p className="mt-2">Description</p>
            <FancyInput
              sMargin
              textArea
              id="notes"
              type="text"
              name="note"
              //   onChange={inputChangeHandler}
              placeholder="Add notes on this Appointment"
            />
          </div>
          <div>
            <div className="d-flex justify-content-between mt-5 align-items-center">
              <FancyInput
                prominant
                sMargin
                id="subtask"
                name="subtask"
                placeholder="Sub Task"
                onChange={(e) => setSubTask(e.target.value)}
              />
              <AddBtn small pale onClick={handalAddSubTask} />
            </div>
            {/* <Input
              options={[{ text: "Call client for follow & get approval" }]}
              checkbox
            />
            <Input options={[{ text: "Order Front brake pad" }]} checkbox /> */}
            {allSubTasks.map((item, i) => {
              return (
                <div className="d-flex justify-content-between sub-tasks">
                  <Input options={[{ text: item }]} checkbox className="m-0" />
                  <img
                    id={i}
                    src="./assets/vectors/delete.svg"
                    alt="delete"
                    onClick={deleteTask}
                    className="hover"
                  />
                </div>
              );
            })}
          </div>
        </div>
      </Modal>
    </div>
  );
};

export default ModalRequests;
