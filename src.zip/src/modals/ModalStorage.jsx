import React, { useState } from "react";
import { Range, getTrackBackground } from 'react-range';
import Modal from "./Modal";
import FancyInput from "../components/FancyInput";
import AddBtn from "../components/AddBtn";
import ModelServices from "./ModalServices";
import { BASEURL, sendNetworkRequest } from "../http/http-request";
import { Direction } from "react-range";
const ModalStorage = (props) => {

  const [formState, setFormState] = useState({
    profile: "",
    type: "",
    location: "",
    box: "",
  });
  const { profile, types, locations } = props;
  const inputChangeHandler = (e) => {
    const { name, value } = e.target;
    setFormState((prevVal) => {
      return { ...prevVal, [name]: value };
    });
  };



  const createStorage = (event) => {
    event.preventDefault();

  };

  const [range, setRange] = useState({ values: [3] })
  
  return (
    <form action="" onSubmit={createStorage}>
      <div>
        <Modal className="modal-appointment" buttonText="Svae" {...props}>
          <div className="client-modal-body">
            <div className="container-fluid px-0">
              <div className="row gy-5">
                <div className="col-lg-12">
                  <div className="row">
                    <h1 className="mb-4">Storage</h1>

                    <div className="col-sm-8 mb-3">
                      <p className="mt-2">Choose Profile</p>
                      <FancyInput
                        select
                        options={
                          typeof profile != "undefined" ? profile : []
                        }
                        id="assignedTo"
                        name="profile"
                        onChange={inputChangeHandler}
                        placeholder="Start Typing"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>
                    <div className="col-sm-4 mb-3">
                      <p className="mt-2">Type</p>
                      <FancyInput
                        select
                        options={
                          typeof types != "undefined" ? types : []
                        }
                        id="assignedTo"
                        name="type"
                        onChange={inputChangeHandler}
                        placeholder="Tires"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>
                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">Location</p>
                      <FancyInput
                        select
                        options={
                          typeof locations != "undefined" ? locations : []
                        }
                        id="assignedTo"
                        name="location"
                        onChange={inputChangeHandler}
                        placeholder="Select in the menu"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>

                    <div className="col-sm-6 mb-3">
                      <p className="mt-2">Box</p>
                      <FancyInput
                        name="box"
                        onChange={inputChangeHandler}
                        placeholder="type a box number"
                        rootClassName="appointment-select"
                        inputClassName="custom-select"
                      />
                    </div>

                  </div>
                </div>
                <div className="col-lg-12">
                  <h2 className="fs-3">Tires wear</h2>
                  <div className="middleCar">
                    <div className="text-center slider-div justify-content-between justify-content-md-evenly align-items-center mb-5">
                      <div className="box">
                        <p>Front Left</p>
                        <div className="d-flex justify-content-between">
                          <div className='slider-horizontal'>
                        
                            <Range
                              values={range.values}
                              step={1}
                              min={0}
                              max={32}
                              onChange={(values) => setRange({ values })}
                              renderTrack={({ props, children }) => (
                                <div
                                  style={{
                                    ...props.style,
                                    height: "36px",
                                    display: "flex",
                                    width: "100%"
                                  }}
                                >
                                  <div
                                    ref={props.ref}
                                    style={{
                                      height: "5px",
                                      width: "100%",
                                      borderRadius: "4px",
                                      background: getTrackBackground({
                                        values: range.values,
                                        colors: ["#548BF4", "#ccc"],
                                        min: 0,
                                        max: 32
                                      }),
                                      alignSelf: "center"
                                    }}
                                  >
                                    {children}
                                  </div>
                                </div>
                              )}
                              renderThumb={({ props, isDragged }) => (
                                <div
                                  {...props}
                                  style={{
                                    ...props.style,
                                    height: "42px",
                                    width: "10px",
                                    borderRadius: "4px",
                                    backgroundColor: "#FFF",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    boxShadow: "0px 2px 6px #AAA"
                                  }}
                                >
                                  <div
                                    style={{
                                      height: "16px",
                                      width: "5px",
                                      backgroundColor: isDragged ? "#548BF4" : "#CCC"
                                    }}
                                  />
                                </div>
                              )}
                            />
                          </div>
                          <div>
                          <FancyInput
                            name="frontLeft"
                            type="checkbox"
                            onChange={inputChangeHandler}
                            rootClassName="appointment-select"
                            inputClassName="custom-select"
                          />
                          </div>
                        </div>
                      </div>
                      <div className="">
                        <p>Front right</p>
                      </div>
                    </div>
                    <div className="d-flex justify-content-between justify-content-md-evenly align-items-center">
                      <div className="">
                        <p>Back Left</p>
                      </div>
                      <div className="">
                        <p>Back right</p>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </Modal>
      </div>
    </form>
  );
};

export default ModalStorage;
