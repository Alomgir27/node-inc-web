import { useState } from "react";
import Modal from "./Modal";
import FancyInput from "../components/FancyInput";
import axios from "axios";

const ModalProfile = (props) => {
  const [serial, setSerial] = useState();
  const [odometer, setOdometer] = useState();
  const [tire, setTire] = useState();
  const [plate, setPlate] = useState();
  const [onRoadProfile, setOnRoadProfile] = useState(false);
  const [nodyMeProfile, setNodyMeProfile] = useState(false);
  const [nodyContactProfile, setNodyContactProfile] = useState(false);
  const [atHomeProfile, setAtHomeProfile] = useState(false);
  const [vehicle, setVehicleProfile] = useState(true);

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const tokens = await JSON.parse(localStorage.getItem("tokens"));
      const carData = await axios({
        method: "GET",
        url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/car/${serial}`,
        headers: {
          Authorization: `Bearer ${tokens.accessToken}`,
          refresh_token: tokens.refreshToken,
          idToken: tokens.idToken,
        },
      });

      console.log(`CARDATA: ${JSON.stringify(carData.data, null, 2)}`);

      const { data } = carData;

      const car = {
        serial,
        odometer,
        tire,
        plate,
        ...data,
      };

      const createdCar = await axios({
        url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/profile`,
        headers: {
          Authorization: `Bearer ${tokens.accessToken}`,
          refresh_token: tokens.refreshToken,
          idToken: tokens.idToken,
        },
        method: "POST",
        data: {
          data: car,
          action_metadata: { test: "test" },
          certification_status: 0,
          xQuantity: 1,
          object_model_revision_id: null,
          parent_object_id: null,
        },
      });

      console.log(`CREATED CAR: ${JSON.stringify(createdCar.data, null, 2)}`);
      console.log(`CURRENT_USER ${JSON.stringify(props.currentUser, null, 2)}`);

      const userWallet = await axios({
        url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/users/wallet/${props.currentUser.entityId}`,
        method: "GET",
        headers: {
          Authorization: `Bearer ${tokens.accessToken}`,
          refresh_token: tokens.refreshToken,
          idToken: tokens.idToken,
        },
      });

      console.log(`USER WALLET: ${JSON.stringify(userWallet.data, null, 2)}`);
      console.log(
        `USER WALLET: ${JSON.stringify(userWallet.data.wallet.id, null, 2)}`
      );

      const owner = await axios({
        url: `https://qz8jew41ki.execute-api.us-east-2.amazonaws.com/prod/profile/owner`,
        method: "POST",
        headers: {
          Authorization: `Bearer ${tokens.accessToken}`,
          refresh_token: tokens.refreshToken,
          idToken: tokens.idToken,
        },
        data: {
          action_metadata: { test: "test" },
          object_id: createdCar.data.ids[0].id,
          is_active: true,
          is_full_owner: true,
          user_id: props.currentUser.id,
          digital_wallet_id: userWallet.data.wallet.id,
        },
      });

      props.setUserProfiles((profiles) => [...profiles, owner.data]);

      console.log(JSON.stringify(owner.data, null, 2));
    } catch (error) {
      console.log(error);
    }
  };

  const handelChangeProfile = (e) => {
    console.log(e.target.value);
    if (e.target.value == "On Road-Car") {
      setOnRoadProfile(true);
      setNodyMeProfile(false);
      setNodyContactProfile(false);
      setAtHomeProfile(false);
      setVehicleProfile(false);
    } else if (e.target.value == "Nody-Me") {
      setOnRoadProfile(false);
      setNodyMeProfile(true);
      setNodyContactProfile(false);
      setAtHomeProfile(false);
      setVehicleProfile(false);
    } else if (e.target.value == "Nody-Contact") {
      setOnRoadProfile(false);
      setNodyMeProfile(false);
      setNodyContactProfile(true);
      setAtHomeProfile(false);
      setVehicleProfile(false);
    } else if (e.target.value == "At home-Location") {
      setOnRoadProfile(false);
      setNodyMeProfile(false);
      setNodyContactProfile(false);
      setAtHomeProfile(true);
      setVehicleProfile(false);
    } else {
      setOnRoadProfile(false);
      setNodyMeProfile(false);
      setNodyContactProfile(false);
      setAtHomeProfile(false);
      setVehicleProfile(true);
    }
  };

  return (
    <div>
      <form onSubmit={(e) => handleSubmit(e)}>
        <Modal
          titleVector="./assets/vectors/modal-profile.svg"
          title="Profile"
          className="profile-modal"
          buttonText="Save"
          headInput={{
            prominant: true,
            select: true,
            id: "type",
            name: "type",
            label: "Profile type",
            options: [
              { text: "Vehicle" },
              { text: "On Road-Car" },
              { text: "Nody-Me" },
              { text: "Nody-Contact" },
              { text: "At home-Location" },
            ],
          }}
          {...props}
          onChange={handelChangeProfile}
        >
          <div className="profile-modal-body">
            <div className="container-fluid px-0">
              {onRoadProfile == true ? (
                <div className="row">
                  <div className="col-sm-6">
                    <p className="mt-2">Vin</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="vin"
                      name="vin"
                      placeholder="Start typing..."
                      onChange={(e) => setSerial(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Node Client</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="client"
                      name="client"
                      placeholder="Start typing..."
                      onChange={(e) => setOdometer(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">YEAR</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                      inputClassName="custom-select"
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">MAKE</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                      inputClassName="custom-select"
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">MODEL</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                      inputClassName="custom-select"
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Odometer</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="vin"
                      name="vin"
                      placeholder="Start typing..."
                      onChange={(e) => setTire(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Plate</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="client"
                      name="client"
                      placeholder="Start typing..."
                      onChange={(e) => setPlate(e.target.value)}
                    />
                  </div>
                </div>
              ) : nodyMeProfile == true ? (
                <div className="row">
                  <div className="col-sm-6">
                    <p className="mt-2">First Name</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="firstname"
                      name="firstname"
                      placeholder="Start typing..."
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Last Name</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="lastname"
                      name="lastname"
                      placeholder="Start typing..."
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">YEAR</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                      inputClassName="custom-select"
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">Month</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                      inputClassName="custom-select"
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">Day</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                      inputClassName="custom-select"
                    />
                  </div>
                </div>
              ) : nodyContactProfile == true ? (
                <div className="row">
                  <div className="col-sm-6">
                    <p className="mt-2">Phone</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="phone"
                      name="phone"
                      placeholder="Start typing..."
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Email</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="email"
                      name="email"
                      placeholder="Start typing..."
                    />
                  </div>
                </div>
              ) : atHomeProfile == true ? (
                <div className="row">
                  <div className="col-sm-12">
                    <p className="mt-2">Address</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="address"
                      name="address"
                      placeholder="Start typing..."
                    />
                  </div>
                </div>
              ) : (
                <div className="row">
                  <div className="col-sm-6">
                    <p className="mt-2">Serial Number</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="vin"
                      name="vin"
                      placeholder="Start typing..."
                      onChange={(e) => setSerial(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Odometer</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="client"
                      name="client"
                      placeholder="Start typing..."
                      onChange={(e) => setOdometer(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-12">
                    <p className="mt-2">Attribute</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="client"
                      name="client"
                      placeholder="Start typing..."
                      onChange={(e) => setOdometer(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">YEAR</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">MAKE</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                    />
                  </div>
                  <div className="col-sm-4">
                    <p className="mt-2">MODEL</p>
                    <FancyInput
                      select
                      options={[
                        {
                          text: "Select the menu",
                          disable: true,
                          selected: true,
                        },
                      ]}
                      id="year"
                      name="year"
                      placeholder="select in the menu"
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Tire Size</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="vin"
                      name="vin"
                      placeholder="Start typing..."
                      onChange={(e) => setTire(e.target.value)}
                    />
                  </div>
                  <div className="col-sm-6">
                    <p className="mt-2">Plate</p>
                    <FancyInput
                      prominant
                      sMargin
                      id="client"
                      name="client"
                      placeholder="Start typing..."
                      onChange={(e) => setPlate(e.target.value)}
                    />
                  </div>
                </div>
              )}
            </div>
          </div>
        </Modal>
      </form>
    </div>
  );
};

export default ModalProfile;
