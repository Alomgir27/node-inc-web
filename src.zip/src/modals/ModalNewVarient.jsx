import React, { useState } from "react";

import Modal from "./Modal";
import FancyInput from "../components/FancyInput";
import AddBtn from "../components/AddBtn";

const ModalNewVarient = (props) => {
  const [variant, setVariant] = useState([]);

  const handelAddVarient = () => {
    let newVariants = (
      <div className="row d-flex align-items-center">
        <div className="col-11 item mr-4">
          <FancyInput
            embossed={false}
            prominant
            rootClassName="my-0"
            id="article"
            name="Article"
            label="Article"
            placeholder="Select an article"
          />
          <img src="./assets/vectors/right-arrow.svg" alt="right-arrow" />
          <FancyInput
            embossed={false}
            prominant
            rootClassName="replace-by my-0"
            id="sku"
            name="sku"
            label="SKU"
            placeholder="Replace by..."
          />
          <FancyInput
            embossed={false}
            prominant
            rootClassName="replace-by my-0"
            id="price"
            name="price"
            label="Price"
            placeholder="Type new price"
          />
        </div>
        <div className="col-1 align-items-center">
          <img
            className=" hover ml-2"
            src="./assets/vectors/delete.svg"
            alt=""
            id={variant.length + 1}
            onClick={deleteVariant}
          />
        </div>
      </div>
    );

    let allVariants = [...variant, newVariants];

    setVariant(allVariants);
  };

  const deleteVariant = (e) => {
    console.log(e.target.id);
    variant.splice(e.target.id);
    setVariant(variant);
  };
  return (
    <div>
      <Modal
        className="varient-modal"
        titleVector="./assets/vectors/modal-new-variant.svg"
        title="New variant"
        forText="Brake Change"
        buttonText="SAVE"
        {...props}
      >
        <div className="varient-modal-body">
          <div className="container-fluid px-0 pb-3">
            <div className="row gx-4">
              <div className="col">
                <p className="mt-2">Year</p>
                <FancyInput
                  prominant
                  rootClassName="my-0"
                  id="article"
                  name="Article"
                  // label="Article"
                  placeholder="Start typeing..."
                />
              </div>
              <div className="col">
                <p className="mt-2">Make</p>
                <FancyInput
                  prominant
                  rootClassName="my-0"
                  id="make"
                  name="Make"
                  placeholder="Start typing..."
                />
              </div>
              <div className="col">
                <p className="mt-2">Model</p>
                <FancyInput
                  prominant
                  rootClassName="my-0"
                  id="model"
                  name="Model"
                  placeholder="Start typing..."
                />
              </div>
            </div>
          </div>

          {variant}

          <AddBtn pale small onClick={handelAddVarient} />
        </div>
      </Modal>
    </div>
  );
};

export default ModalNewVarient;
