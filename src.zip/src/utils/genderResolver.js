export const genderResolver = {
  0: "Male",
  1: "Female",
  2: "Other",
  3: "Unspecified",
};
